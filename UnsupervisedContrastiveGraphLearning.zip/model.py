# -*- coding: utf-8 -*-
"""
Created on Mon Nov 21 00:14:07 2022

@author: WXC
"""


import torch.nn as nn
from encoder1 import Module_1,Module_2


class Pretext(nn.Module):
    """
    Build a Pretext model.
    """
    def __init__(self, dim=64, pred_dim=32):
        """
        dim: feature dimension (default: 64)
        pred_dim: hidden dimension of the predictor (default: 32) 
        """
        super(Pretext, self).__init__()

        # create the extractor   
        self.first_extractor=Module_1(1,None,True)
        self.second_extractor=Module_2(1,None,True)
      
       
        # build MLP predictor
        self.predictor = nn.Sequential()
        self.predictor.add_module('L1',nn.Linear(dim, pred_dim,bias=False)), # first fc layer
        self.predictor.add_module('BN',nn.BatchNorm1d(pred_dim)),
        self.predictor.add_module('RL',nn.ReLU(inplace=True)),
        self.predictor.add_module('L2',  nn.Linear(pred_dim, dim)) # second fc layer
 
    def forward(self, X1, X2):
        """
        Input:
            X1: augmented BOLD signals X1 
            X2: augmented BOLD signals X2
        Output:
            p1, p2, z1, z2: predictors and targets of the network
        """

        # compute features for one view
        z1 = self. first_extractor(X1) 
        z2 = self. second_extractor(X2)

        p1 = self.predictor(z1)
        p2 = self.predictor(z2) 

        return p1, p2, z1.detach(), z2.detach() #stop gradient