# -*- coding: utf-8 -*-
"""
Created on Sun Nov 20 22:11:01 2022

@author: WXC
"""

import scipy.io
import numpy as np
import torch
from einops import rearrange
            
 
class MDD(object):
     def read_data(self):
         site20 = scipy.io.loadmat('F:\\UnsupervisedRepresentationLearning_Mar-2022\\SITE20.mat')
         bold20 =site20['AAL']
         
         A20 =bold20[0]
         series20=[]
               
         data_alla1 = None
         data_alla2 = None
         
         for i in range(len(A20)): #subjects
             signal20 = A20[i]
             series20.append(signal20)
             X1=signal20[:209,:] #BOLD signal slice
             X2=signal20[23:,:]
             
             if data_alla1 is None:              
                data_alla1 = X1
             else:
                data_alla1 = np.concatenate((data_alla1, X1), axis=0)
                
             if data_alla2 is None:              
                data_alla2 = X2
             else:
                data_alla2 = np.concatenate((data_alla2, X2), axis=0)  
        
         
         
         data20 =np.array(series20) 
         x1=data20[:,:209,:]  
         x2=data20[:,23:,:]
         data1= rearrange(x1, '(a b) c (d e) -> a b c d e', a=533, b=1, d=116, e=1) #augmmented X1 (N,C,T,V,M)
         data2= rearrange(x2, '(a b) c (d e) -> a b c d e', a=533, b=1, d=116, e=1) #augmmented X2
         
         
         return data_alla1,data_alla2,data1,data2
     def __init__(self):
         super(MDD,self).__init__()
         data_alla1,data_alla2,data1,data2=self.read_data()
         self.data1 =torch.from_numpy(data1)
         self.data2 =torch.from_numpy(data2)
         self.n_samples =data1.shape[0]    
     
     def __len__(self):
         return self.n_samples
     def __getitem__(self, index):
          return self.data1[index]   



def covariance_matrx(data_all):
    n_regions = 116
    A = np.zeros((n_regions, n_regions))
    for i in range(n_regions):
        for j in range(i, n_regions):
            if i == j:
                A[i][j] = 1
            else:
                A[i][j] = abs(np.corrcoef(data_all[:,i], data_all[:,j])[0][1])  # get value from corrcoef matrix
                A[j][i] = A[i][j]
   
    return A


