# -*- coding: utf-8 -*-
"""
Created on Mon Nov 21 00:08:24 2022

@author: WXC
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import sys
sys.path.append('F:\\UnsupervisedRepresentationLearning_Mar-2022\\cnslab_fmri-master')
from net.utils.tgcn import ConvTemporalGraphical
import numpy as np
from data import MDD,covariance_matrx


class Module_1(nn.Module):
    r"""Spatial temporal graph convolutional networks.

    Args:
        in_channels (int): Number of channels in the input data
        num_class (int): Number of classes for the classification task
        graph_args (dict): The arguments for building the graph
        edge_importance_weighting (bool): If ``True``, adds a learnable
            importance weighting to the edges of the graph
        **kwargs (optional): Other parameters for graph convolution units

    Shape:
        - Input: :math:`(N, in_channels, T_{in}, V_{in}, M_{in})`
        - Output: :math:`(N, out_channels)` where
            :math:`N` is a batch size,
            :math:`T_{in}` is a length of input sequence,
            :math:`V_{in}` is the number of graph nodes,
            :math:`M_{in}` is the number of instance in a frame.
    """

    def __init__(self,in_channels, graph_args,
                 edge_importance_weighting, **kwargs):
        super().__init__()

       
        train_dataset=MDD()
        data_alla1,data_alla2,data1,data2=train_dataset.read_data()
        A1=covariance_matrx(data_alla1) #this is the adj matrix that computes correlation based on augmented data for all T timesteps
        Dl = np.sum(A1, 0)
        num_node = A1.shape[0]
      
        Dn = np.zeros((num_node, num_node)) #(116,116)
        for i in range(num_node):
            if Dl[i] > 0:
                Dn[i, i] = Dl[i] ** (-0.5)
        DAD = np.dot(np.dot(Dn, A1), Dn) #Laplacian matrix

        temp_matrix = np.zeros((1, A1.shape[0], A1.shape[0])) #shape (1,116,116)
        temp_matrix[0] = DAD
        A = torch.tensor(temp_matrix, dtype=torch.float32, requires_grad=False)
        self.register_buffer('A', A) #A will not be updated during model training
    
        # build networks (**number of layers, final output features, kernel size**)
        spatial_kernel_size = A.size(0)  #1
        temporal_kernel_size = 11 
        kernel_size = (temporal_kernel_size, spatial_kernel_size)
        self.data_bn = nn.BatchNorm1d(in_channels * A.size(1))  #nn.BatchNorm1d(116) dimensions that need to be normalized
        kwargs0 = {k: v for k, v in kwargs.items() if k != 'dropout'}
        self.st_gcn_networks = nn.ModuleList((
            st_gcn(in_channels, 64, kernel_size, 1, residual=False, **kwargs0),
            st_gcn(64, 64, kernel_size, 1, residual=False, **kwargs),
            st_gcn(64, 64, kernel_size, 1, residual=False, **kwargs),
           
        )) #in_channels=1, out_channels=64

        # initialize parameters for edge importance weighting
        if edge_importance_weighting:
           
            self.edge_importance = nn.Parameter(torch.ones(self.A.size())) #shape (1,116,116)
        else:
            self.edge_importance = [1] * len(self.st_gcn_networks)
        
        #self.fcn = nn.Conv2d(64, 1, kernel_size=1)
        #self.sig = nn.Sigmoid()
       
       
    def forward(self, x):

        # data normalization
        N, C, T, V, M = x.size()           
        x = x.permute(0, 4, 3, 1, 2).contiguous()  #N,M,V,C,T
        x = x.view(N * M, V * C, T) #N,V,T
        x = self.data_bn(x)
        x = x.view(N, M, V, C, T)
        x = x.permute(0, 1, 3, 4, 2).contiguous() #N,M,C,T,V
        x = x.view(N * M, C, T, V)  #N,C,T,V
        
        for gcn in self.st_gcn_networks:
            x, _ = gcn(x, self.A * (self.edge_importance*self.edge_importance+torch.transpose(self.edge_importance*self.edge_importance,1,2)))

        # global pooling
        x = F.avg_pool2d(x, x.size()[2:])
        x = x.view(N, M, -1, 1, 1).mean(dim=1) #(N,out_channels,1,1)
        x = x.view(-1,64) #(N,out_channels)
       
        return x

   


class Module_2(nn.Module):
   

    def __init__(self,in_channels, graph_args,
                 edge_importance_weighting, **kwargs):
        super().__init__()

        train_dataset=MDD()
        data_alla1,data_alla2,data1,data2=train_dataset.read_data()
        A2=covariance_matrx(data_alla2)
        Dl = np.sum(A2, 0)
        num_node = A2.shape[0]
        Dn = np.zeros((num_node, num_node))
        for i in range(num_node):
            if Dl[i] > 0:
                Dn[i, i] = Dl[i] ** (-0.5)
        DAD = np.dot(np.dot(Dn, A2), Dn)

        temp_matrix = np.zeros((1, A2.shape[0], A2.shape[0]))
        temp_matrix[0] = DAD
       
        A = torch.tensor(temp_matrix, dtype=torch.float32, requires_grad=False)
        
        self.register_buffer('A', A)
        
        spatial_kernel_size = A.size(0)  
        temporal_kernel_size = 11 
        kernel_size = (temporal_kernel_size, spatial_kernel_size)
        self.data_bn = nn.BatchNorm1d(in_channels * A.size(1))
        kwargs0 = {k: v for k, v in kwargs.items() if k != 'dropout'}
        self.st_gcn_networks = nn.ModuleList((
            st_gcn(in_channels, 64, kernel_size, 1, residual=False, **kwargs0),
            st_gcn(64, 64, kernel_size, 1, residual=False, **kwargs),
            st_gcn(64, 64, kernel_size, 1, residual=False, **kwargs),
          
        ))

       
        if edge_importance_weighting:
            
            self.edge_importance = nn.Parameter(torch.ones(self.A.size()))
        else:
            self.edge_importance = [1] * len(self.st_gcn_networks)
        
        self.fcn = nn.Conv2d(64, 1, kernel_size=1)
        self.sig = nn.Sigmoid()
      
    def forward(self, x):
       
        N, C, T, V, M = x.size()  
        x = x.permute(0, 4, 3, 1, 2).contiguous()  
        x = x.view(N * M, V * C, T)
        x = self.data_bn(x)
        x = x.view(N, M, V, C, T)
        x = x.permute(0, 1, 3, 4, 2).contiguous()
        x = x.view(N * M, C, T, V)

        for gcn in self.st_gcn_networks:
            x, _ = gcn(x, self.A * (self.edge_importance*self.edge_importance+torch.transpose(self.edge_importance*self.edge_importance,1,2)))

        x = F.avg_pool2d(x, x.size()[2:])
        x = x.view(N, M, -1, 1, 1).mean(dim=1)
        x = x.view(-1,64)

        return x

   

class st_gcn(nn.Module):
    r"""Applies a spatial temporal graph convolution over an input graph sequence.

    Args:
        in_channels (int): Number of channels in the input sequence data
        out_channels (int): Number of channels produced by the convolution
        kernel_size (tuple): Size of the temporal convolving kernel and graph convolving kernel
        stride (int, optional): Stride of the temporal convolution. Default: 1
        dropout (int, optional): Dropout rate of the final output. Default: 0
        residual (bool, optional): If ``True``, applies a residual mechanism. Default: ``True``

    Shape:
        - Input[0]: Input graph sequence in :math:`(N, in_channels, T_{in}, V, M)` format
        - Input[1]: Input graph adjacency matrix in :math:`(K, V, V)` format
        - Output[0]: Output graph sequence in :math:`(N, out_channels, T_{out}, V)` format
        - Output[1]: Graph adjacency matrix for output data in :math:`(K, V, V)` format

        where
            :math:`N` is a batch size,
            :math:`K` is the spatial kernel size, as :math:`K == kernel_size[1]`,
            :math:`T_{in}/T_{out}` is a length of input/output sequence,
            :math:`V` is the number of graph nodes.

    """

    def __init__(self,
                 in_channels,
                 out_channels,
                 kernel_size,
                 stride=1,
                 dropout=0.5,
                 residual=True):
        super().__init__()
        print("Dropout={}".format(dropout))
        assert len(kernel_size) == 2
        assert kernel_size[0] % 2 == 1
        padding = ((kernel_size[0] - 1) // 2, 0) #(5,0)
        
        #spatial convolution
        self.gcn = ConvTemporalGraphical(in_channels, out_channels,
                                         kernel_size[1])
        #temporal convolution
        self.tcn = nn.Sequential(
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(
                out_channels,
                out_channels,
                (kernel_size[0], 1),
                (stride, 1),
                padding,
            ),
            nn.BatchNorm2d(out_channels),
            nn.Dropout(dropout, inplace=True),
        )

        if not residual:
            self.residual = lambda x: 0

        elif (in_channels == out_channels) and (stride == 1):
            self.residual = lambda x: x

        else:
            self.residual = nn.Sequential(
                nn.Conv2d(
                    in_channels,
                    out_channels,
                    kernel_size=1,
                    stride=(stride, 1)),
                nn.BatchNorm2d(out_channels),
            )

        self.relu = nn.ReLU(inplace=True)

    def forward(self, x, A):

        res = self.residual(x)
        x, A = self.gcn(x, A)
        x = self.tcn(x) + res

        return self.relu(x), A